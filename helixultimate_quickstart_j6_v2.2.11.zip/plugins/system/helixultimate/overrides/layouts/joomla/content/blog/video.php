<?php

/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2025 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
 */

defined('JPATH_BASE') or die();

use HelixUltimate\Framework\Platform\Helper;

extract($displayData);

if (isset($attribs->helix_ultimate_video) && $attribs->helix_ultimate_video) {
	$video_url = trim($attribs->helix_ultimate_video);
	$video_src = '';
	$embed_code = '';

	$video = parse_url($video_url);
	$host = isset($video['host']) ? strtolower($video['host']) : '';
	$ext = strtolower(pathinfo($video_url, PATHINFO_EXTENSION));

	switch ($host) {
		case 'youtu.be':
			$rawId = trim($video['path'] ?? '', '/');
			$video_id = preg_replace('/[^A-Za-z0-9_-]/', '', $rawId);
			if ($video_id !== '') {
				$video_src = '//www.youtube.com/embed/' . $video_id;
			}
			break;

		case 'www.youtube.com':
		case 'youtube.com':
		case 'www.youtube-nocookie.com':
		case 'youtube-nocookie.com':
			$path = $video['path'] ?? '';
			if (strpos($path, '/embed/') === 0) {
				$rawId = substr($path, 7);
				$video_id = preg_replace('/[^A-Za-z0-9_-]/', '', $rawId);
				if ($video_id !== '') {
					$video_src = '//www.youtube.com/embed/' . $video_id;
				}
			} else {
				parse_str($video['query'] ?? '', $query);
				if (isset($query['v'])) {
					$video_id = preg_replace('/[^A-Za-z0-9_-]/', '', (string) $query['v']);
					if ($video_id !== '') {
						$video_src = '//www.youtube.com/embed/' . $video_id;
					}
				}
			}
			break;

		case 'vimeo.com':
		case 'www.vimeo.com':
		case 'player.vimeo.com':
			$path = trim($video['path'] ?? '', '/');
			if (strpos($path, 'video/') === 0) {
				$path = substr($path, 6);
			}
			$rawId = explode('?', $path)[0];
			$video_id = preg_replace('/[^0-9]/', '', $rawId);
			if ($video_id !== '') {
				$video_src = '//player.vimeo.com/video/' . $video_id;
			}
			break;

		case 'dailymotion.com':
		case 'www.dailymotion.com':
			$path = trim($video['path'] ?? '', '/');
			if (strpos($path, 'video/') === 0) {
				$path = substr($path, 6);
			}
			$rawId = explode('_', $path)[0];
			$video_id = preg_replace('/[^A-Za-z0-9_-]/', '', $rawId);
			if ($video_id !== '') {
				$video_src = '//www.dailymotion.com/embed/video/' . $video_id;
			}
			break;

		case 'dai.ly':
			$path = trim($video['path'] ?? '', '/');
			$video_id = preg_replace('/[^A-Za-z0-9_-]/', '', $path);
			if ($video_id !== '') {
				$video_src = '//www.dailymotion.com/embed/video/' . $video_id;
			}
			break;

		default:
			if ($ext === 'mp4') {
				$embed_code = '
					<video controls width="100%">
						<source src="' . htmlspecialchars($video_url, ENT_QUOTES, 'UTF-8') . '" type="video/mp4">
						Your browser does not support the video tag.
					</video>';
			} elseif (strpos($video_url, '<iframe') !== false || strpos($video_url, '<video') !== false) {
				$embed_code = Helper::sanitizeEmbed($video_url);
			} else {
				$embed_code = Helper::sanitizeEmbed(
					'<iframe src="' . htmlspecialchars($video_url, ENT_QUOTES, 'UTF-8') . '" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>'
				);
			}
			break;
	}

	if ($embed_code) {
	?>
		<div class="article-featured-video">
			<div class="ratio ratio-16x9">
				<?php echo $embed_code; ?>
			</div>
		</div>

	<?php
	} elseif ($video_src) {
	?>
		<div class="article-featured-video">
			<div class="ratio ratio-16x9">
				<iframe src="<?php echo htmlspecialchars($video_src, ENT_QUOTES, 'UTF-8'); ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			</div>
		</div>
	<?php
	}
}
