<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  System.logout
 *
 * @copyright   (C) 2023 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Plugin\System\Logout\Extension\Logout;

return new class () implements ServiceProviderInterface {
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     *
     * @since   4.4.0
     */
    public function register(Container $container): void
    {
        // The logout plugin is a special case which does not use the lazy loading because it
        // uses the constructor to delete a cookie
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                return new Logout(
                    (array) PluginHelper::getPlugin('system', 'logout'),
                    Factory::getApplication()
                );
            }
        );
    }
};
