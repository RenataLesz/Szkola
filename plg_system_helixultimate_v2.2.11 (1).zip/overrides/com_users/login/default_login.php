<?php

/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2025 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
 */

defined('_JEXEC') or die;

use HelixUltimate\Framework\Platform\Settings;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\Users\Site\View\Login\HtmlView $cookieLogin */

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate');

$usersConfig = ComponentHelper::getParams('com_users');

?>
<div class="com-users-login login">
    <div class="row justify-content-center">
        <div class="col-lg-4">
            <?php if ($this->params->get('show_page_heading')) : ?>
                <div class="page-header">
                    <h1>
                        <?php echo $this->escape($this->params->get('page_heading')); ?>
                    </h1>
                </div>
            <?php endif; ?>

            <?php if (($this->params->get('logindescription_show') == 1 && str_replace(' ', '', $this->params->get('login_description', '')) != '') || $this->params->get('login_image') != '') : ?>
                <div class="com-users-login__description login-description">
                <?php endif; ?>

                <?php if ($this->params->get('logindescription_show') == 1) : ?>
                    <?php echo $this->params->get('login_description'); ?>
                <?php endif; ?>

                <?php if ($this->params->get('login_image') != '') : ?>
                    <?php echo HTMLHelper::_('image', $this->params->get('login_image'), empty($this->params->get('login_image_alt')) && empty($this->params->get('login_image_alt_empty')) ? false : $this->params->get('login_image_alt'), ['class' => 'com-users-login__image login-image']); ?>
                <?php endif; ?>

                <?php if (($this->params->get('logindescription_show') == 1 && str_replace(' ', '', $this->params->get('login_description', '')) != '') || $this->params->get('login_image') != '') : ?>
                </div>
            <?php endif; ?>

            <form action="<?php echo Route::_('index.php?option=com_users&task=user.login'); ?>" method="post" class="com-users-login__form form-validate form-horizontal well" id="com-users-login__form">
                <fieldset>

                <?php foreach ($this->form->getFieldset('credentials') as $field) : ?>
                    <?php
                    $showon = $field->getAttribute('showon');
                    $attribs = '';
                    if ($showon) {
                        $attribs .= ' data-showon=\'' . json_encode(Settings::parseShowOnConditions($showon, $field->formControl)) . '\'';
                    }
                    // Enable disable on
                    $enableOn = $field->getAttribute('enableon', '');
                    if ($enableOn) {
                        $attribs .= ' data-enableon="' . $enableOn . '"';
                    }
                    ?>
                    <?php if (!$field->hidden) : ?>
                        <div class="mb-3" <?php echo $attribs; ?>>
                            <?php echo $field->label; ?>
                            <?php echo $field->input; ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>


                <?php if (PluginHelper::isEnabled('system', 'remember')) : ?>
                    <div class="com-users-login__remember mb-3">
                        <div class="form-check">
                            <input class="form-check-input" id="remember" type="checkbox" name="remember" value="yes">
                            <label class="form-check-label" for="remember">
                                <?php echo Text::_('COM_USERS_LOGIN_REMEMBER_ME'); ?>
                            </label>
                        </div>
                    </div>
                <?php endif; ?>

                <?php foreach ($this->extraButtons as $button) :
                    $dataAttributeKeys = array_filter(array_keys($button), function ($key) {
                        return substr($key, 0, 5) == 'data-';
                    });
                ?>
                    <div class="com-users-login__submit control-group">
                        <div class="mb-3">
                            <button type="button"
                                class="btn btn-secondary w-100 <?php echo $button['class'] ?? '' ?>"
                                <?php foreach ($dataAttributeKeys as $key) : ?>
                                <?php echo $key ?>="<?php echo $button[$key] ?>"
                                <?php endforeach; ?>
                                <?php if ($button['onclick']) : ?>
                                onclick="<?php echo $button['onclick'] ?>"
                                <?php endif; ?>
                                title="<?php echo Text::_($button['label']) ?>"
                                id="<?php echo $button['id'] ?>">
                                <?php if (!empty($button['icon'])) : ?>
                                    <span class="<?php echo $button['icon'] ?>"></span>
                                <?php elseif (!empty($button['image'])) : ?>
                                    <?php echo HTMLHelper::_('image', $button['image'], Text::_($button['tooltip'] ?? ''), [
                                        'class' => 'icon',
                                    ], true) ?>
                                <?php elseif (!empty($button['svg'])) : ?>
                                    <?php echo $button['svg']; ?>
                                <?php endif; ?>
                                <?php echo Text::_($button['label']) ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="com-users-login__submit control-group">
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            <?php echo Text::_('JLOGIN'); ?>
                        </button>
                    </div>
                </div>

                <?php if (version_compare(JVERSION, '6.0.0', '>=')) : ?>
                    <?php echo $this->form->renderControlFields(); ?>
                <?php else : ?>
                    <?php $return = $this->form->getValue('return', '', $this->params->get('login_redirect_url', $this->params->get('login_redirect_menuitem', ''))); ?>
                    <input type="hidden" name="return" value="<?php echo base64_encode($return); ?>">
                    <?php echo HTMLHelper::_('form.token'); ?>
                <?php endif; ?>
                </fieldset>
            </form>
            <div class="com-users-login__options list-group">
                <a class="com-users-login__reset list-group-item" href="<?php echo Route::_('index.php?option=com_users&view=reset'); ?>">
                    <?php echo Text::_('COM_USERS_LOGIN_RESET'); ?>
                </a>
                <a class="com-users-login__remind list-group-item" href="<?php echo Route::_('index.php?option=com_users&view=remind'); ?>">
                    <?php echo Text::_('COM_USERS_LOGIN_REMIND'); ?>
                </a>
                <?php
                if ($usersConfig->get('allowUserRegistration')) :
                    $registrationLink = 'index.php?option=com_users&view=registration';

                    if (version_compare(JVERSION, '6.0.0', '>=')) {
                        $registrationMenuId = $this->params->get('customRegLinkMenu');

                        if ($registrationMenuId && Factory::getApplication()->getMenu()->getItem($registrationMenuId)) {
                            $registrationLink = 'index.php?Itemid=' . (int) $registrationMenuId;
                        }
                    }
                    ?>
                    <a class="com-users-login__register list-group-item" href="<?php echo Route::_($registrationLink); ?>">
                        <?php echo Text::_('COM_USERS_LOGIN_REGISTER'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
